

<?php $__env->startSection('content'); ?>
    
    <div class="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 mb-6">
        <div>
            <h1 class="text-2xl font-bold">Clientes do consultor</h1>
            <p class="text-sm opacity-70">Gerencie os clientes vinculados ao seu perfil.</p>
        </div>

        <a href="<?php echo e(route('consultant.clients.create', ['consultant' => $consultantModel->id])); ?>"
            class="btn btn-primary btn-sm sm:btn-md">
            <i class="fa fa-user-plus mr-2"></i> Novo cliente
        </a>
    </div>

    <?php if (isset($component)) { $__componentOriginal2920fece7093889c66f6edad9ca62216 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2920fece7093889c66f6edad9ca62216 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.alert-status','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('alert-status'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2920fece7093889c66f6edad9ca62216)): ?>
<?php $attributes = $__attributesOriginal2920fece7093889c66f6edad9ca62216; ?>
<?php unset($__attributesOriginal2920fece7093889c66f6edad9ca62216); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2920fece7093889c66f6edad9ca62216)): ?>
<?php $component = $__componentOriginal2920fece7093889c66f6edad9ca62216; ?>
<?php unset($__componentOriginal2920fece7093889c66f6edad9ca62216); ?>
<?php endif; ?>

    
    <div class="flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3 mb-4">
        
        <form method="GET" class="join w-full md:w-auto">
            <input name="q" value="<?php echo e(request('q')); ?>" type="text" placeholder="Buscar por nome ou e-mail"
                class="input input-bordered join-item w-full md:w-80" />
            <button class="btn btn-ghost join-item" type="submit">
                <i class="fa fa-search"></i>
            </button>
            <?php if(request()->filled('q')): ?>
                <a href="<?php echo e(route('consultant.clients.index', ['consultant' => $consultantModel->id])); ?>"
                    class="btn btn-ghost join-item" title="Limpar">
                    <i class="fa fa-times"></i>
                </a>
            <?php endif; ?>
        </form>

        
        <form method="GET" class="flex gap-2">
            <input type="hidden" name="q" value="<?php echo e(request('q')); ?>">
            <select name="status" class="select select-bordered select-sm md:select-md">
                <option value="">Todos os status</option>
                <?php $__currentLoopData = ['ativo' => 'Ativo', 'inativo' => 'Inativo', 'pendente' => 'Pendente']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($value); ?>" <?php if(request('status') === $value): echo 'selected'; endif; ?>><?php echo e($label); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <button class="btn btn-ghost btn-sm md:btn-md" type="submit">
                Filtrar
            </button>
        </form>
    </div>

    
    <div class="card bg-base-100 shadow">
        <div class="card-body p-0">
            <div class="overflow-x-auto">
                <table class="table table-zebra">
                    <thead>
                        <tr class="bg-base-200">
                            <th>Nome</th>
                            <th>E-mail</th>
                            <th class="whitespace-nowrap">Status</th>
                            <th class="text-right">Ações</th>
                        </tr>
                    </thead>

                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <?php
                                $name = $client->user?->name ?? '—';
                                $email = $client->user?->email ?? '—';
                                $status = $client->status ?? 'pendente';
                                $badge = match ($status) {
                                    'ativo' => 'badge-success',
                                    'inativo' => 'badge-neutral',
                                    'pendente' => 'badge-warning',
                                    default => 'badge-ghost',
                                };
                                $initials = collect(explode(' ', $name))
                                    ->filter()
                                    ->map(fn($p) => mb_substr($p, 0, 1))
                                    ->take(2)
                                    ->implode('');
                            ?>

                            <tr class="hover">
                                <td class="max-w-64">
                                    <div class="flex items-center gap-3">
                                        <div class="avatar placeholder">
                                            <div class="w-8 rounded-full bg-base-300">
                                                <span class="text-xs"><?php echo e($initials ?: '■'); ?></span>
                                            </div>
                                        </div>
                                        <div class="truncate" title="<?php echo e($name); ?>"><?php echo e($name); ?></div>
                                    </div>
                                </td>

                                <td class="truncate max-w-72" title="<?php echo e($email); ?>"><?php echo e($email); ?></td>

                                <td>
                                    <span class="badge badge-sm <?php echo e($badge); ?>"><?php echo e($status); ?></span>
                                </td>

                                <td class="text-right">
                                    
                                    <div class="hidden sm:inline-flex join">
                                        <a class="btn btn-xs join-item"
                                            href="<?php echo e(route('consultant.clients.show', ['consultant' => $consultantModel->id, 'client' => $client->id])); ?>">
                                            Ver
                                        </a>

                                        <a class="btn btn-xs btn-outline join-item"
                                            href="<?php echo e(route('consultant.clients.edit', ['consultant' => $consultantModel->id, 'client' => $client->id])); ?>">
                                            Editar
                                        </a>

                                        <form method="POST"
                                            action="<?php echo e(route('consultant.clients.destroy', ['consultant' => $consultantModel->id, 'client' => $client->id])); ?>"
                                            onsubmit="return confirm('Remover este cliente?')" class="join-item">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button class="btn btn-xs btn-error">Remover</button>
                                        </form>
                                    </div>

                                    
                                    <div class="dropdown dropdown-end sm:hidden">
                                        <div tabindex="0" role="button" class="btn btn-ghost btn-xs">
                                            <i class="fa fa-ellipsis-v"></i>
                                        </div>
                                        <ul tabindex="0"
                                            class="menu menu-sm dropdown-content z-[1] p-2 shadow bg-base-100 rounded-box w-40">
                                            <li>
                                                <a
                                                    href="<?php echo e(route('consultant.clients.show', ['consultant' => $consultantModel->id, 'client' => $client->id])); ?>">Ver</a>
                                            </li>
                                            <li>
                                                <a
                                                    href="<?php echo e(route('consultant.clients.edit', ['consultant' => $consultantModel->id, 'client' => $client->id])); ?>">Editar</a>
                                            </li>
                                            <li>
                                                <form method="POST"
                                                    action="<?php echo e(route('consultant.clients.destroy', ['consultant' => $consultantModel->id, 'client' => $client->id])); ?>"
                                                    onsubmit="return confirm('Remover este cliente?')">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>
                                                    <button class="text-error">Remover</button>
                                                </form>
                                            </li>
                                        </ul>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="4">
                                    <div class="alert justify-center my-4">
                                        <i class="fa fa-users"></i>
                                        <span class="text-sm">Nenhum cliente encontrado.</span>
                                    </div>
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    
    <div class="mt-4 flex justify-end">
        <?php echo e($clients->withQueryString()->links()); ?>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\user\Documents\GitHub\consultor-financeiro\resources\views\consultants\clients\index.blade.php ENDPATH**/ ?>