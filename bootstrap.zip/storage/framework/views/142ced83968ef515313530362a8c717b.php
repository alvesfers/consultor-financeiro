<?php $__env->startSection('content'); ?>
    <div class="tw-flex tw-justify-between tw-items-center tw-mb-6">
        <h1 class="tw-text-2xl tw-font-bold">Tarefas</h1>
        <a href="<?php echo e(route('consultants.tasks.create')); ?>" class="tw-btn tw-btn-primary">Nova tarefa</a>
    </div>

    <?php if (isset($component)) { $__componentOriginal2920fece7093889c66f6edad9ca62216 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2920fece7093889c66f6edad9ca62216 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.alert-status','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('alert-status'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2920fece7093889c66f6edad9ca62216)): ?>
<?php $attributes = $__attributesOriginal2920fece7093889c66f6edad9ca62216; ?>
<?php unset($__attributesOriginal2920fece7093889c66f6edad9ca62216); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2920fece7093889c66f6edad9ca62216)): ?>
<?php $component = $__componentOriginal2920fece7093889c66f6edad9ca62216; ?>
<?php unset($__componentOriginal2920fece7093889c66f6edad9ca62216); ?>
<?php endif; ?>

    <div class="tw-card tw-bg-base-100 tw-shadow tw-overflow-x-auto">
        <table class="tw-table">
            <thead>
                <tr>
                    <th>Título</th>
                    <th>Vencimento</th>
                    <th>Status</th>
                    <th class="tw-w-40">Ações</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($t->title); ?></td>
                        <td><?php echo e(optional($t->due_date)->format('d/m/Y') ?? '—'); ?></td>
                        <td>
                            <?php if($t->done): ?>
                                <span class="tw-badge tw-badge-success">Concluída</span>
                            <?php else: ?>
                                <span class="tw-badge">Pendente</span>
                            <?php endif; ?>
                        </td>
                        <td class="tw-flex tw-gap-2">
                            <a class="tw-btn tw-btn-xs tw-btn-outline"
                                href="<?php echo e(route('consultants.tasks.edit', $t)); ?>">Editar</a>
                            <form method="POST" action="<?php echo e(route('consultants.tasks.destroy', $t)); ?>"
                                onsubmit="return confirm('Excluir tarefa?')">
                                <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                <button class="tw-btn tw-btn-xs tw-btn-error">Excluir</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="4" class="tw-text-center tw-text-sm tw-opacity-70">Nenhuma tarefa.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <div class="tw-mt-4"><?php echo e($tasks->links()); ?></div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\user\Documents\GitHub\consultor-financeiro\resources\views\consultants\tasks\index.blade.php ENDPATH**/ ?>