

<?php $__env->startSection('content'); ?>
    <?php
        function money_br($v)
        {
            return 'R$ ' . number_format((float) $v, 2, ',', '.');
        }
        $hasAny = collect($filters)->some(fn($v) => filled($v));
        $toggleDir = fn($col) => request('sort', 'grp_created_at') === $col && request('dir', 'desc') === 'desc'
            ? 'asc'
            : 'desc';
        $orderLink = function ($col, $label) use ($toggleDir, $consultantId) {
            $params = array_merge(request()->query(), ['sort' => $col, 'dir' => $toggleDir($col)]);
            return route('client.transactions.index', ['consultant' => $consultantId] + $params);
        };
    ?>

    <div class="p-4 space-y-6">

        
        <div class="flex items-center justify-between gap-4 flex-wrap">
            <div>
                <h1 class="text-2xl font-semibold">Transações</h1>
                <p class="text-sm text-base-content/60">Agrupadas por compra parcelada. Clique para ver parcelas.</p>
            </div>
            <div class="flex items-center gap-2">
                <a href="<?php echo e(route('client.transactions.export', ['consultant' => $consultantId] + request()->query())); ?>"
                    class="btn btn-outline btn-sm">
                    <i class="fa-solid fa-file-arrow-down mr-2"></i> Exportar CSV
                </a>
                <a href="<?php echo e(route('client.transactions.index', ['consultant' => $consultantId])); ?>"
                    class="btn btn-ghost btn-sm">
                    Limpar filtros
                </a>
            </div>
        </div>

        
        <div class="stats shadow bg-base-100">
            <div class="stat">
                <div class="stat-title">Total de grupos</div>
                <div class="stat-value text-primary"><?php echo e(number_format($summary['count'])); ?></div>
                <div class="stat-desc">com os filtros atuais</div>
            </div>
            <div class="stat">
                <div class="stat-title">Entradas</div>
                <div class="stat-value text-success"><?php echo e(money_br($summary['in'])); ?></div>
            </div>
            <div class="stat">
                <div class="stat-title">Saídas</div>
                <div class="stat-value text-error"><?php echo e(money_br($summary['out'])); ?></div>
            </div>
        </div>

        
        <details class="collapse bg-base-200 rounded-box">
            <summary class="collapse-title text-md font-medium flex items-center gap-2">
                <i class="fa-solid fa-filter"></i> Filtros
                <?php if($hasAny): ?>
                    <span class="badge badge-primary badge-outline ml-2">ativos</span>
                <?php endif; ?>
            </summary>
            <div class="collapse-content">
                <form method="GET" class="grid md:grid-cols-6 grid-cols-2 gap-3">
                    <label class="form-control">
                        <span class="label-text">Grupo</span>
                        <select name="group_id" class="select select-bordered">
                            <option value="">Todos</option>
                            <?php $__currentLoopData = $categoryGroups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $g): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($g->id); ?>" <?php if($filters['group_id'] == $g->id): echo 'selected'; endif; ?>><?php echo e($g->name); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </label>

                    <label class="form-control">
                        <span class="label-text">Categoria</span>
                        <select name="category_id" class="select select-bordered">
                            <option value="">Todas</option>
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($c->id); ?>" <?php if($filters['category_id'] == $c->id): echo 'selected'; endif; ?>><?php echo e($c->name); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </label>

                    <label class="form-control">
                        <span class="label-text">Subcategoria</span>
                        <select name="subcategory_id" class="select select-bordered">
                            <option value="">Todas</option>
                            <?php $__currentLoopData = $subcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($s->id); ?>" <?php if($filters['subcategory_id'] === $s->id): echo 'selected'; endif; ?>><?php echo e($s->name); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </label>

                    <label class="form-control">
                        <span class="label-text">Conta</span>
                        <input class="input input-bordered" name="account_id" type="number"
                            value="<?php echo e($filters['account_id']); ?>">
                    </label>

                    <label class="form-control">
                        <span class="label-text">Cartão</span>
                        <input class="input input-bordered" name="card_id" type="number"
                            value="<?php echo e($filters['card_id']); ?>">
                    </label>

                    <label class="form-control md:col-span-2">
                        <span class="label-text">Busca</span>
                        <input type="text" name="q" value="<?php echo e($filters['q']); ?>" class="input input-bordered"
                            placeholder="nota, método, status..." />
                    </label>

                    <label class="form-control">
                        <span class="label-text">De</span>
                        <input type="date" name="date_start" value="<?php echo e($filters['date_start']); ?>"
                            class="input input-bordered" />
                    </label>

                    <label class="form-control">
                        <span class="label-text">Até</span>
                        <input type="date" name="date_end" value="<?php echo e($filters['date_end']); ?>"
                            class="input input-bordered" />
                    </label>

                    <label class="form-control">
                        <span class="label-text">Itens/página</span>
                        <select name="per_page" class="select select-bordered">
                            <?php $__currentLoopData = [10, 20, 50, 100]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $n): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($n); ?>" <?php if((int) request('per_page', 20) === $n): echo 'selected'; endif; ?>><?php echo e($n); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </label>

                    <div class="md:col-span-2 flex gap-2 items-end">
                        <button class="btn btn-primary"><i class="fa-solid fa-magnifying-glass mr-2"></i>Aplicar</button>
                        <a href="<?php echo e(route('client.transactions.index', ['consultant' => $consultantId])); ?>"
                            class="btn btn-ghost">Limpar</a>
                    </div>
                </form>

                <?php if($hasAny): ?>
                    <div class="mt-3 flex flex-wrap gap-2">
                        <?php $__currentLoopData = ['group_id' => 'Grupo', 'category_id' => 'Categoria', 'subcategory_id' => 'Subcategoria', 'account_id' => 'Conta', 'card_id' => 'Cartão']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if(filled($filters[$key])): ?>
                                <span class="badge badge-outline"><?php echo e($label); ?> #<?php echo e($filters[$key]); ?></span>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php if(filled($filters['q'])): ?>
                            <span class="badge badge-outline">Busca: “<?php echo e($filters['q']); ?>”</span>
                        <?php endif; ?>
                        <?php if(filled($filters['date_start']) || filled($filters['date_end'])): ?>
                            <span class="badge badge-outline">Período: <?php echo e($filters['date_start'] ?: '∞'); ?> →
                                <?php echo e($filters['date_end'] ?: '∞'); ?></span>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>
            </div>
        </details>

        
        <div class="md:hidden space-y-3">
            <?php $__empty_1 = true; $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $g): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <?php
                    $isNeg = ((float) $g->sum_amount) < 0;
                    $parcelas = $g->installment_count ?: $g->items_count;
                    $amountClass = $isNeg ? 'text-error' : 'text-success';
                    $date = \Carbon\Carbon::parse($g->repr_date)->format('d/m');
                ?>
                <details class="collapse bg-base-100 shadow-sm">
                    <summary class="collapse-title p-4">
                        <div class="flex items-center gap-3">
                            <div class="avatar">
                                <div class="w-8 rounded">
                                    <?php if($g->bank_logo): ?>
                                        <img src="<?php echo e($g->bank_logo); ?>" alt="bank" />
                                    <?php else: ?>
                                        <i class="fa-solid fa-landmark mt-1"></i>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="flex-1">
                                <div class="font-medium line-clamp-1"><?php echo e($g->notes ?: '—'); ?></div>
                                <div class="text-xs text-base-content/60">Ref.: <?php echo e($date); ?> •
                                    <?php echo e($g->method ?: '—'); ?> • <?php echo e($g->status ?: '—'); ?></div>
                            </div>
                            <div class="text-right">
                                <div class="font-semibold <?php echo e($amountClass); ?>"><?php echo e(money_br($g->sum_amount)); ?></div>
                                <?php if($parcelas > 1): ?>
                                    <div class="text-[11px] text-base-content/60"><?php echo e($parcelas); ?>x</div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </summary>
                    <div class="collapse-content pt-0">
                        <div class="overflow-x-auto">
                            <table class="table table-sm">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Conta</th>
                                        <th>Cartão</th>
                                        <th>Categoria</th>
                                        <th class="text-right">Valor</th>
                                        <th class="text-center">Data</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $g->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $it): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php
                                            $cat = trim(
                                                ($it->category_name ?: '—') .
                                                    ($it->subcategory_name ? ' / ' . $it->subcategory_name : ''),
                                            );
                                            $dt = \Carbon\Carbon::parse($it->date)->format('d/m');
                                        ?>
                                        <tr>
                                            <td><?php echo e($it->installment_index ?: '—'); ?></td>
                                            <td><?php echo e($it->account_name ?: '—'); ?></td>
                                            <td><?php echo e($it->card_name ?: '—'); ?></td>
                                            <td><?php echo e($cat); ?></td>
                                            <td class="text-right"><?php echo e(money_br($it->amount)); ?></td>
                                            <td class="text-center"><?php echo e($dt); ?></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </details>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="text-center text-base-content/60 py-8">Sem transações com estes filtros.</div>
            <?php endif; ?>
        </div>

        
        <div class="hidden md:block overflow-x-auto">
            <table class="table table-zebra">
                <thead>
                    <tr>
                        <th class="w-12">Banco</th>
                        <th><a class="link" href="<?php echo e($orderLink('notes', 'Notas')); ?>">Notas</a></th>
                        <th class="text-center">Parcelas</th>
                        <th class="text-right"><a class="link" href="<?php echo e($orderLink('sum_amount', 'Total')); ?>">Total</a>
                        </th>
                        <th class="text-center"><a class="link" href="<?php echo e($orderLink('repr_date', 'Data ref.')); ?>">Data
                                ref.</a></th>
                        <th class="text-center"><a class="link"
                                href="<?php echo e($orderLink('grp_created_at', 'Criado em')); ?>">Criado em</a></th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $g): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <?php
                            $isNeg = ((float) $g->sum_amount) < 0;
                            $amountClass = $isNeg ? 'text-error' : 'text-success';
                            $parcelas = $g->installment_count ?: $g->items_count;
                            $date = \Carbon\Carbon::parse($g->repr_date)->format('d/m');
                            $created = \Carbon\Carbon::parse($g->grp_created_at)->format('d/m H:i');
                        ?>

                        <tr class="hover">
                            <td>
                                <?php if($g->bank_logo): ?>
                                    <img src="<?php echo e($g->bank_logo); ?>" class="w-6 h-6 object-contain" alt="bank" />
                                <?php else: ?>
                                    <i class="fa-solid fa-landmark text-base-content/60"></i>
                                <?php endif; ?>
                            </td>
                            <td class="align-top">
                                <details>
                                    <summary class="font-medium cursor-pointer">
                                        <?php echo e($g->notes ?: '—'); ?>

                                        <span class="ml-2 badge badge-ghost"><?php echo e($g->method ?: '—'); ?></span>
                                        <span class="ml-2 badge badge-ghost"><?php echo e($g->status ?: '—'); ?></span>
                                    </summary>
                                    <div class="mt-2">
                                        <div class="overflow-x-auto">
                                            <table class="table table-sm">
                                                <thead>
                                                    <tr>
                                                        <th>#</th>
                                                        <th>Conta</th>
                                                        <th>Cartão</th>
                                                        <th>Categoria</th>
                                                        <th class="text-right">Valor</th>
                                                        <th class="text-center">Data</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php $__currentLoopData = $g->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $it): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php
                                                            $cat = trim(
                                                                ($it->category_name ?: '—') .
                                                                    ($it->subcategory_name
                                                                        ? ' / ' . $it->subcategory_name
                                                                        : ''),
                                                            );
                                                            $dt = \Carbon\Carbon::parse($it->date)->format('d/m');
                                                        ?>
                                                        <tr>
                                                            <td><?php echo e($it->installment_index ?: '—'); ?></td>
                                                            <td><?php echo e($it->account_name ?: '—'); ?></td>
                                                            <td><?php echo e($it->card_name ?: '—'); ?></td>
                                                            <td><?php echo e($cat); ?></td>
                                                            <td class="text-right"><?php echo e(money_br($it->amount)); ?></td>
                                                            <td class="text-center"><?php echo e($dt); ?></td>
                                                        </tr>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </details>
                            </td>
                            <td class="text-center">
                                <?php if($parcelas > 1): ?>
                                    <span class="badge badge-outline"><?php echo e($parcelas); ?>x</span>
                                <?php else: ?>
                                    —
                                <?php endif; ?>
                            </td>
                            <td class="text-right font-semibold <?php echo e($amountClass); ?>"><?php echo e(money_br($g->sum_amount)); ?></td>
                            <td class="text-center"><?php echo e($date); ?></td>
                            <td class="text-center text-base-content/70"><?php echo e($created); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="6" class="text-center text-base-content/60">Sem transações para os filtros
                                aplicados.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        
        <div class="flex justify-between items-center gap-3 flex-wrap">
            <div class="text-sm text-base-content/60">
                Mostrando <span class="font-medium"><?php echo e($groups->firstItem()); ?></span>–<span
                    class="font-medium"><?php echo e($groups->lastItem()); ?></span>
                de <span class="font-medium"><?php echo e($groups->total()); ?></span> grupos
            </div>
            <div><?php echo e($groups->onEachSide(1)->links()); ?></div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\user\Documents\GitHub\consultor-financeiro\resources\views\consultants\clients\transactions\index.blade.php ENDPATH**/ ?>