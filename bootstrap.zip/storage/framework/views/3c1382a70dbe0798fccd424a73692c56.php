<?php if(session('status')): ?>
    <div class="tw-alert tw-alert-success tw-mb-4">
        <span><?php echo e(session('status')); ?></span>
    </div>
<?php endif; ?>
<?php /**PATH C:\Users\user\Documents\GitHub\consultor-financeiro\resources\views\components\alert-status.blade.php ENDPATH**/ ?>