

<?php $__env->startSection('content'); ?>
    <div class="max-w-3xl mx-auto">
        <div class="flex items-center justify-between mb-4">
            <h1 class="text-2xl font-bold flex items-center gap-2">
                <i class="fa-regular fa-pen-to-square"></i> Editar categoria
            </h1>
            <a href="<?php echo e(route('consultant.categories.index', ['consultant' => $consultant])); ?>" class="btn btn-ghost">
                <i class="fa-solid fa-arrow-left-long me-2"></i>Voltar
            </a>
        </div>

        <?php if(session('success')): ?>
            <div class="alert alert-success mb-4"><i class="fa-regular fa-circle-check"></i> <?php echo e(session('success')); ?></div>
        <?php endif; ?>
        <?php if($errors->any()): ?>
            <div class="alert alert-error mb-4">
                <i class="fa-regular fa-circle-xmark me-2"></i>
                <ul class="list-disc ms-5">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($e); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

        <div class="card bg-base-100 border border-base-300">
            <div class="card-body">
                <form method="POST"
                    action="<?php echo e(route('consultant.categories.update', ['consultant' => $consultant, 'category' => $category->id])); ?>"
                    class="space-y-3">
                    <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>

                    <div class="form-control">
                        <label class="label"><span class="label-text">Nome</span></label>
                        <input type="text" name="name" class="input input-bordered" required maxlength="120"
                            value="<?php echo e(old('name', $category->name)); ?>" />
                    </div>

                    <div class="form-control">
                        <label class="label"><span class="label-text">Categoria pai (opcional)</span></label>
                        <select name="parent_id" class="select select-bordered">
                            <option value="">— Sem pai —</option>
                            <?php $__currentLoopData = $parents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($p->id); ?>" <?php if(old('parent_id', $category->parent_id) == $p->id): echo 'selected'; endif; ?>><?php echo e($p->name); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <label class="label cursor-pointer justify-start gap-3">
                        <input type="checkbox" name="is_active" class="toggle toggle-primary"
                            <?php if(old('is_active', $category->is_active)): echo 'checked'; endif; ?> />
                        <span class="label-text">Ativa</span>
                    </label>

                    <div class="card-actions justify-end">
                        <button class="btn btn-primary">
                            <i class="fa-solid fa-floppy-disk me-2"></i>Salvar alterações
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\user\Documents\GitHub\consultor-financeiro\resources\views\consultants\categories\edit.blade.php ENDPATH**/ ?>