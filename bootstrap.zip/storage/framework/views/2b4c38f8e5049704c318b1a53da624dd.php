

<?php $__env->startSection('content'); ?>
    
    <?php if(session('status')): ?>
        <div class="alert alert-success mb-4">
            <i class="fa-solid fa-circle-check"></i>
            <span><?php echo e(session('status')); ?></span>
        </div>
    <?php endif; ?>

    
    <div class="flex items-center justify-between mb-4">
        <div>
            <h1 class="text-2xl font-semibold">
                Cliente: <?php echo e($client->user?->name ?? '—'); ?>

            </h1>
            <p class="opacity-70 text-sm">Resumo financeiro e atividades recentes</p>
        </div>

        <div class="flex items-center gap-2">
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update', $client)): ?>
                <a class="btn btn-primary" href="<?php echo e(route('consultant.tasks.create', ['consultant' => $consultantId])); ?>">
                    <i class="fa-solid fa-list-check mr-2"></i> Criar tarefa
                </a>

                <a class="btn"
                    href="<?php echo e(route('consultant.clients.edit', ['consultant' => $consultantId, 'client' => $client->id])); ?>">
                    <i class="fa-solid fa-user-pen mr-2"></i> Editar cliente
                </a>
            <?php endif; ?>
        </div>
    </div>

    
    <div class="grid grid-cols-1 lg:grid-cols-4 gap-4 mb-6">
        
        <div class="card shadow bg-base-100">
            <div class="card-body">
                <div class="flex items-center justify-between">
                    <div>
                        <div class="text-sm opacity-60">Saldo atual</div>
                        <div class="text-3xl font-semibold"><?php echo e(number_format($balance ?? 0, 2, ',', '.')); ?></div>
                    </div>
                    <i class="fa-solid fa-wallet text-3xl text-primary"></i>
                </div>
                <div class="mt-2 text-xs opacity-60">Aberturas + movimentações em conta</div>
                <div class="mt-4 h-14 w-full bg-base-200 rounded-box"></div>
            </div>
        </div>

        
        <div class="card shadow bg-base-100">
            <div class="card-body">
                <div class="flex items-center justify-between">
                    <div>
                        <div class="text-sm opacity-60">Tasks pendentes</div>
                        <div class="text-3xl font-semibold"><?php echo e($tasksPendingCount ?? 0); ?></div>
                    </div>
                    <i class="fa-solid fa-list-check text-3xl text-warning"></i>
                </div>
                <a class="link mt-3" href="<?php echo e(route('consultant.tasks.index', ['consultant' => $consultantId])); ?>">Ver
                    todas</a>
                <div class="mt-4 h-14 w-full bg-base-200 rounded-box"></div>
            </div>
        </div>

        
        <div class="card shadow bg-base-100">
            <div class="card-body">
                <div class="flex items-center justify-between">
                    <div>
                        <div class="text-sm opacity-60">Objetivos pendentes</div>
                        <div class="text-3xl font-semibold"><?php echo e($goalsPendingCount ?? 0); ?></div>
                    </div>
                    <i class="fa-solid fa-bullseye text-3xl text-accent"></i>
                </div>
                <div class="mt-4 h-14 w-full bg-base-200 rounded-box"></div>
            </div>
        </div>

        
        <div class="card shadow bg-gradient-to-br from-base-200 to-base-100">
            <div class="card-body">
                <div class="flex items-center justify-between">
                    <div>
                        <div class="text-sm opacity-60">Ações rápidas</div>
                        <div class="mt-2 flex gap-2">
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update', $client)): ?>
                                <a class="btn btn-sm btn-primary"
                                    href="<?php echo e(route('consultant.tasks.create', ['consultant' => $consultantId])); ?>">
                                    <i class="fa-solid fa-plus mr-2"></i> Nova tarefa
                                </a>
                                <a class="btn btn-sm"
                                    href="<?php echo e(route('consultant.clients.edit', ['consultant' => $consultantId, 'client' => $client->id])); ?>">
                                    <i class="fa-solid fa-user-pen mr-2"></i> Editar cliente
                                </a>
                            <?php endif; ?>
                        </div>
                    </div>
                    <i class="fa-solid fa-bolt text-3xl text-success"></i>
                </div>
                <div class="mt-4 h-14 w-full bg-base-200 rounded-box"></div>
            </div>
        </div>
    </div>

    
    <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        <div class="card bg-base-100 shadow">
            <div class="card-body">
                <h2 class="card-title">
                    <i class="fa-solid fa-building-columns mr-2"></i> Contas do cliente
                </h2>
                <ul class="mt-2 space-y-3">
                    <?php $__empty_1 = true; $__currentLoopData = $accounts ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <li class="flex items-center justify-between">
                            <div>
                                <div class="font-medium"><?php echo e($a->name); ?></div>
                                <div class="text-xs opacity-70">
                                    <?php echo e($a->type); ?> <?php if(!$a->on_budget): ?>
                                        • fora do orçamento
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="text-right">
                                <div class="text-xs opacity-70 mt-1">
                                    Abertura: <?php echo e(number_format($a->opening_balance, 2, ',', '.')); ?>

                                </div>
                            </div>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <li class="opacity-70">Nenhuma conta cadastrada.</li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>

        
        <div class="card bg-base-100 shadow lg:col-span-2">
            <div class="card-body">
                <div class="flex items-center justify-between">
                    <h2 class="card-title">
                        <i class="fa-solid fa-arrow-right-arrow-left mr-2"></i> Transações recentes
                    </h2>
                </div>

                <div class="overflow-x-auto mt-3">
                    <table class="table table-zebra">
                        <thead>
                            <tr>
                                <th>Data</th>
                                <th>Conta</th>
                                <th>Categoria</th>
                                <th class="text-right">Valor</th>
                                <th>Notas</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $recentTransactions ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tx): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e(\Illuminate\Support\Carbon::parse($tx->date)->format('d/m/Y')); ?></td>
                                    <td><?php echo e($tx->account?->name ?? '—'); ?></td>
                                    <td><?php echo e($tx->category?->name ?? '—'); ?></td>
                                    <td class="text-right <?php echo e(($tx->amount ?? 0) < 0 ? 'text-error' : 'text-success'); ?>">
                                        <?php echo e(number_format($tx->amount ?? 0, 2, ',', '.')); ?>

                                    </td>
                                    <td><?php echo e($tx->notes); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="5" class="opacity-70">Sem transações.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\user\Documents\GitHub\consultor-financeiro\resources\views\consultants\clients\show.blade.php ENDPATH**/ ?>