

<?php $__env->startSection('content'); ?>
    <?php
        // ========= Helpers usadas no template =========
        function money_br($v)
        {
            return 'R$ ' . number_format((float) $v, 2, ',', '.');
        }

        // Define cor de fundo conforme o % gasto (null => neutro)
        function bg_color_by_percent($p)
        {
            if (is_null($p)) {
                return 'bg-base-100';
            } // sem meta
            if ($p >= 90) {
                return 'bg-red-50';
            }
            if ($p >= 60) {
                return 'bg-amber-50';
            }
            return 'bg-green-50';
        }

        // Badge de status (sem meta => neutro)
        function badge_status($balance, $percent, $hasGoal)
        {
            if (!$hasGoal) {
                return ['badge-ghost', 'Sem meta'];
            }
            if ($balance < 0) {
                return ['badge-error', 'Ultrapassou'];
            }
            if ($percent >= 90) {
                return ['badge-warning', 'Atenção'];
            }
            return ['badge-success', 'Ok'];
        }

        function saldo_color($balance)
        {
            if (is_null($balance)) {
                return '';
            }
            return $balance < 0 ? 'text-red-600' : 'text-green-600';
        }

        // ========= Dados para o componente =========
        $breakdownByMonth = collect($cards)->mapWithKeys(fn($c) => [$c['ym'] => $c['subs_breakdown']]);
        $namesMap = collect($cards)->flatMap(
            fn($c) => collect($c['items'])->mapWithKeys(fn($i) => [$i['category_id'] => $i['category_name']]),
        );
    ?>

    <script>
        // Deixa os dados prontos num objeto global simples
        window._goalsInit = {
            months: <?php echo e((int) $monthsCount); ?>,
            endYm: <?php echo json_encode($endYm, 15, 512) ?>,
            categoryId: <?php echo $filterCategoryId ? (int) $filterCategoryId : 'null'; ?>,
            breakdownByMonth: <?php echo json_encode($breakdownByMonth, 15, 512) ?>,
            names: <?php echo json_encode($namesMap, 15, 512) ?>,
        };

        // Define o componente ANTES do x-data usar
        window.goalsPage = function(initial) {
            return {
                months: initial.months,
                endYm: initial.endYm,
                categoryId: initial.categoryId,
                breakdownByMonth: initial.breakdownByMonth || {},
                names: initial.names || {},
                modal: {
                    title: '',
                    items: [],
                    total_br: 'R$ 0,00'
                },

                go() {
                    const params = new URLSearchParams();
                    params.set('months', this.months || 6);
                    params.set('end', this.endYm || '');
                    if (this.categoryId) params.set('category_id', this.categoryId);
                    window.location = <?php echo json_encode(route('client.goals.index', ['consultant' => $consultantId]), 512) ?> + '?' + params.toString();
                },

                openBreakdown(ym, categoryId) {
                    const map = this.breakdownByMonth?.[ym] ?? {};
                    const rows = map?.[categoryId] ?? [];
                    let total = 0;

                    const fmt = (v) => {
                        const n = Number(v || 0);
                        return 'R$ ' + n.toLocaleString('pt-BR', {
                            minimumFractionDigits: 2,
                            maximumFractionDigits: 2
                        });
                    };

                    const items = rows.map(r => {
                        total += Number(r.spent || 0);
                        return {
                            ...r,
                            spent_br: fmt(r.spent)
                        };
                    });

                    this.modal.title = (this.names?.[categoryId] || 'Categoria') + ' • ' + ym;
                    this.modal.items = items;
                    this.modal.total_br = fmt(total);

                    this.$refs.subsModal.showModal();
                }
            }
        }
    </script>

    <div class="p-4 space-y-6" x-data="goalsPage(window._goalsInit)">

        
        <div class="breadcrumbs text-sm text-base-content/70">
            <ul>
                <li><a class="link" href="<?php echo e(route('client.dashboard', ['consultant' => $consultantId])); ?>">Início</a></li>
                <li>Metas</li>
            </ul>
        </div>

        <div class="flex items-center justify-between">
            <div>
                <h1 class="text-2xl font-semibold">Metas • Comparativo mensal</h1>
                <p class="opacity-70 text-sm">
                    Inclui categorias de despesas mesmo sem meta. Clique em uma categoria para ver o detalhamento por
                    subcategoria.
                </p>
            </div>
        </div>

        
        <div class="card bg-base-100 shadow-sm">
            <div class="card-body grid gap-4 md:grid-cols-5">
                <div>
                    <label class="label"><span class="label-text">Meses</span></label>
                    <select class="select select-bordered w-full" x-model.number="months">
                        <option value="3">Últimos 3</option>
                        <option value="6" selected>Últimos 6</option>
                        <option value="12">Últimos 12</option>
                    </select>
                </div>

                <div>
                    <label class="label"><span class="label-text">Mês final</span></label>
                    <input type="month" class="input input-bordered w-full" x-model="endYm">
                </div>

                <div class="md:col-span-2">
                    <label class="label"><span class="label-text">Categoria (Despesas)</span></label>
                    <select class="select select-bordered w-full" x-model.number="categoryId">
                        <option value="">Todas</option>
                        <?php $__currentLoopData = $categoryOptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($c->id); ?>" <?php if($filterCategoryId === $c->id): echo 'selected'; endif; ?>><?php echo e($c->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <div class="md:col-span-1 flex items-end">
                    <button class="btn btn-primary w-full" @click="go()">
                        <i class="fa-solid fa-magnifying-glass mr-2"></i> Aplicar
                    </button>
                </div>
            </div>
        </div>

        
        <div class="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
            <?php $__empty_1 = true; $__currentLoopData = $cards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $card): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="card bg-base-100 shadow-md border border-base-200">
                    <div class="card-body">
                        
                        <div class="flex items-center justify-between mb-3">
                            <h2 class="card-title"><?php echo e($card['label']); ?></h2>
                            <span class="badge badge-outline"><?php echo e($card['ym']); ?></span>
                        </div>

                        <?php if(empty($card['items'])): ?>
                            <div class="text-sm opacity-70">Não há dados para este mês.</div>
                        <?php else: ?>
                            <div class="overflow-x-auto">
                                <table class="table table-compact w-full">
                                    <thead>
                                        <tr>
                                            <th>Categoria</th>
                                            <th class="text-right">Gasto</th>
                                            <th class="text-right">Meta</th>
                                            <th class="text-right">Saldo</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $card['items']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $it): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php
                                                $hasGoal = !is_null($it['limit']);
                                                $bg = bg_color_by_percent($it['percent']);
                                                [$badgeClass, $badgeText] = badge_status(
                                                    $it['balance'],
                                                    $it['percent'],
                                                    $hasGoal,
                                                );
                                            ?>
                                            <tr class="<?php echo e($bg); ?> hover:bg-base-200 cursor-pointer"
                                                @click="openBreakdown('<?php echo e($card['ym']); ?>', <?php echo e($it['category_id']); ?>)">
                                                <td>
                                                    <div class="flex items-center gap-2">
                                                        <i class="fa-solid fa-chevron-right text-xs opacity-60"></i>
                                                        <div class="flex flex-col">
                                                            <span class="font-medium"><?php echo e($it['category_name']); ?></span>
                                                            <span class="text-xs opacity-70">
                                                                <span
                                                                    class="badge <?php echo e($badgeClass); ?> badge-sm"><?php echo e($badgeText); ?></span>
                                                            </span>
                                                        </div>
                                                    </div>
                                                </td>
                                                <td class="text-right font-medium"><?php echo e(money_br($it['spent'])); ?></td>
                                                <td class="text-right">
                                                    <?php echo e($hasGoal ? money_br($it['limit']) : '—'); ?>

                                                </td>
                                                <td class="text-right font-semibold <?php echo e(saldo_color($it['balance'])); ?>">
                                                    <?php if(is_null($it['balance'])): ?>
                                                        —
                                                    <?php else: ?>
                                                        <?php echo e($it['balance'] >= 0 ? '+' : '-'); ?><?php echo e(money_br(abs($it['balance']))); ?>

                                                    <?php endif; ?>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>

                                    
                                    <tfoot>
                                        <tr>
                                            <th class="text-right">Total do mês</th>
                                            <th class="text-right font-bold"><?php echo e(money_br($card['total_spent'])); ?></th>
                                            <th></th>
                                            <th></th>
                                        </tr>
                                    </tfoot>
                                </table>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="md:col-span-2 xl:col-span-3">
                    <div class="alert">
                        <i class="fa-solid fa-circle-info"></i>
                        <span>Nenhum dado encontrado para o intervalo selecionado.</span>
                    </div>
                </div>
            <?php endif; ?>
        </div>

        
        <dialog id="subsModal" class="modal" x-ref="subsModal">
            <div class="modal-box max-w-lg">
                <h3 class="font-bold text-lg mb-2">
                    <i class="fa-solid fa-list mr-2"></i>
                    <span x-text="modal.title"></span>
                </h3>

                <div x-show="modal.items.length === 0" class="opacity-70">Sem gastos neste mês.</div>

                <div x-show="modal.items.length > 0" class="overflow-x-auto">
                    <table class="table table-compact w-full">
                        <thead>
                            <tr>
                                <th>Subcategoria</th>
                                <th class="text-right">Gasto</th>
                            </tr>
                        </thead>
                        <tbody>
                            <template x-for="row in modal.items" :key="row.id">
                                <tr>
                                    <td x-text="row.name"></td>
                                    <td class="text-right font-medium" x-text="row.spent_br"></td>
                                </tr>
                            </template>
                        </tbody>
                        <tfoot>
                            <tr>
                                <th class="text-right">Total</th>
                                <th class="text-right" x-text="modal.total_br"></th>
                            </tr>
                        </tfoot>
                    </table>
                </div>

                <div class="modal-action">
                    <form method="dialog">
                        <button class="btn">Fechar</button>
                    </form>
                </div>
            </div>
            <form method="dialog" class="modal-backdrop">
                <button>close</button>
            </form>
        </dialog>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\user\Documents\GitHub\consultor-financeiro\resources\views\consultants\clients\goals\index.blade.php ENDPATH**/ ?>