<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>" data-theme="ekon">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo e(config('app.name', 'Consultor Financeiro')); ?></title>

    
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" />
    <?php echo $__env->yieldPushContent('head'); ?>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>

    <style>
        /* iOS safe-area para Dock/FAB */
        :root {
            --safe-bottom: env(safe-area-inset-bottom, 0px);
        }

        .safe-bottom {
            padding-bottom: calc(1rem + var(--safe-bottom));
        }

        .dock-safe {
            padding-bottom: var(--safe-bottom);
        }

        .fab-safe {
            bottom: calc(1rem + var(--safe-bottom));
        }
    </style>
</head>

<body class="min-h-screen" x-data="{
    collapsed: JSON.parse(localStorage.getItem('sbCollapsed') ?? 'false'),
    toggle() { this.collapsed = !this.collapsed;
        localStorage.setItem('sbCollapsed', JSON.stringify(this.collapsed)); }
}">

    <?php
        $user = auth()->user();
        $role = $user->role ?? null;
        $consultantId = $user?->consultant?->id ?? ($user?->client?->consultant_id ?? null);

        // helper de rota com parâmetro do consultor
        $rConsultant = fn($name) => $consultantId ? route($name, ['consultant' => $consultantId]) : route('dashboard');

        // helper p/ FA ícones
        if (!function_exists('fa')) {
            function fa($classes)
            {
                return "<i class='{$classes} text-base'></i>";
            }
        }

        $icons = [
            'dashboard' => fa('fa-solid fa-gauge-high'),
            'users' => fa('fa-solid fa-user-group'),
            'clients' => fa('fa-solid fa-address-book'),
            'tasks' => fa('fa-solid fa-list-check'),
            'categories' => fa('fa-solid fa-tags'),
            'settings' => fa('fa-solid fa-gear'),
            'accounts' => fa('fa-solid fa-wallet'),
            'invoices' => fa('fa-solid fa-file-invoice-dollar'),
            'monthly_goals' => fa('fa-solid fa-bullseye'),
            'transactions' => fa('fa-solid fa-right-left'),
            'objectives' => fa('fa-solid fa-flag-checkered'),
            'investments' => fa('fa-solid fa-chart-line'),
            'reports' => fa('fa-solid fa-file-lines'),
            'plus' => fa('fa-solid fa-plus'),
            'transfer' => fa('fa-solid fa-arrow-right-arrow-left'),
            'goal' => fa('fa-solid fa-bullseye'),
            'clientAdd' => fa('fa-solid fa-user-plus'),
            'taskAdd' => fa('fa-solid fa-square-plus'),
            'default' => fa('fa-regular fa-circle'),
        ];

        $cHref = function (string $name) use ($rConsultant) {
            return \Illuminate\Support\Facades\Route::has($name) ? $rConsultant($name) : '#';
        };

        $icon = fn(string $key) => $icons[$key] ?? $icons['default'];

        $collapsedLink = function (string $pattern) {
            $isActive = request()->routeIs($pattern);
            return [
                'isActive' => $isActive,
                'a' =>
                    ($isActive ? 'bg-base-200 ring-1 ring-base-300' : 'hover:bg-base-100') .
                    ' flex flex-col items-center py-3 rounded-lg transition-all duration-150 ease-out active:scale-[.98]',
                'icon' => $isActive ? 'text-primary text-lg' : '',
                'label' => 'text-[10px] mt-1 leading-none ' . ($isActive ? 'font-semibold' : ''),
                'aria' => $isActive ? 'page' : 'false',
            ];
        };

        // helper pro estado ativo do Dock
        $dockActive = fn(string $pattern) => request()->routeIs($pattern) ? 'dock-active' : '';

    ?>

    <div class="drawer lg:drawer-open">
        <input id="app-drawer" type="checkbox" class="drawer-toggle" />

        
        <div class="drawer-content flex flex-col">

            
            <header class="navbar bg-base-100 border-b border-base-300 px-4 sticky top-0 z-30">
                <div class="flex-none lg:hidden">
                    <label for="app-drawer" aria-label="Abrir menu lateral" class="btn btn-ghost btn-square">
                        <i class="fa-solid fa-bars"></i>
                    </label>
                </div>

                <div class="flex-1 min-w-0">
                    <a href="<?php echo e(route('home')); ?>" class="btn btn-ghost text-xl truncate">
                        <?php echo e(config('app.name', 'Consultor Financeiro')); ?>

                    </a>
                </div>

                <div class="flex-none gap-2">
                    

                    <div class="dropdown dropdown-end">
                        <div tabindex="0" role="button" class="btn btn-ghost">
                            <div class="flex items-center gap-2">
                                <div class="avatar placeholder">
                                    <div class="bg-neutral text-neutral-content rounded-full w-8">
                                        <span class="text-xs"><?php echo e(strtoupper(substr($user->name ?? 'U', 0, 1))); ?></span>
                                    </div>
                                </div>
                                <span
                                    class="hidden sm:block max-w-[12ch] truncate"><?php echo e($user->name ?? 'Usuário'); ?></span>
                            </div>
                        </div>
                        <ul tabindex="0"
                            class="menu menu-sm dropdown-content bg-base-200 rounded-box z-[60] mt-3 w-56 p-2 shadow">
                            <li><a href="<?php echo e(route('profile.edit')); ?>"><i class="fa-regular fa-user me-2"></i>Perfil</a>
                            </li>
                            <li>
                                <form method="POST" action="<?php echo e(route('logout')); ?>">
                                    <?php echo csrf_field(); ?>
                                    <button type="submit">
                                        <i class="fa-solid fa-right-from-bracket me-2"></i>Sair
                                    </button>
                                </form>
                            </li>
                        </ul>
                    </div>
                </div>
            </header>

            
            <main class="p-4 lg:p-6 pb-24 sm:pb-10 safe-bottom">
                <?php echo $__env->yieldContent('content'); ?>
                <?php echo $__env->make('partials.flash', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            </main>

            
            <nav class="sm:hidden fixed inset-x-0 bottom-0 z-40">
                <div class="dock dock-md bg-base-100/95 backdrop-blur border-t border-base-300 dock-safe">
                    <?php if($role === 'client'): ?>
                        <a href="<?php echo e($cHref('client.dashboard')); ?>" class="<?php echo e($dockActive('client.dashboard')); ?>">
                            <?php echo $icon('dashboard'); ?><span class="dock-label">Início</span>
                        </a>
                        <a href="<?php echo e($cHref('client.transactions.index')); ?>"
                            class="<?php echo e($dockActive('client.transactions*')); ?>">
                            <?php echo $icon('transactions'); ?><span class="dock-label">Transações</span>
                        </a>
                        <a href="<?php echo e($cHref('client.invoices.index')); ?>" class="<?php echo e($dockActive('client.invoices*')); ?>">
                            <?php echo $icon('invoices'); ?><span class="dock-label">Faturas</span>
                        </a>
                        <a href="<?php echo e($cHref('client.accounts.index')); ?>" class="<?php echo e($dockActive('client.accounts*')); ?>">
                            <?php echo $icon('accounts'); ?><span class="dock-label">Contas</span>
                        </a>
                        <a href="<?php echo e(route('settings')); ?>" class="<?php echo e($dockActive('settings*')); ?>">
                            <?php echo $icon('settings'); ?><span class="dock-label">Config</span>
                        </a>
                    <?php elseif($role === 'consultant'): ?>
                        <a href="<?php echo e($rConsultant('consultant.dashboard')); ?>"
                            class="<?php echo e($dockActive('consultant.dashboard')); ?>">
                            <?php echo $icon('dashboard'); ?><span class="dock-label">Dashboard</span>
                        </a>
                        <a href="<?php echo e($rConsultant('consultant.clients.index')); ?>"
                            class="<?php echo e($dockActive('consultant.clients.*')); ?>">
                            <?php echo $icon('clients'); ?><span class="dock-label">Clientes</span>
                        </a>
                        <a href="<?php echo e($rConsultant('consultant.tasks.index')); ?>"
                            class="<?php echo e($dockActive('consultant.tasks.*')); ?>">
                            <?php echo $icon('tasks'); ?><span class="dock-label">Tarefas</span>
                        </a>
                        <a href="<?php echo e($rConsultant('consultant.categories.index')); ?>"
                            class="<?php echo e($dockActive('consultant.categories.*')); ?>">
                            <?php echo $icon('categories'); ?><span class="dock-label">Categorias</span>
                        </a>
                        <a href="<?php echo e(route('settings')); ?>" class="<?php echo e($dockActive('settings*')); ?>">
                            <?php echo $icon('settings'); ?><span class="dock-label">Config</span>
                        </a>
                    <?php elseif($role === 'admin'): ?>
                        <a href="<?php echo e(route('admin.dashboard')); ?>" class="<?php echo e($dockActive('admin.dashboard')); ?>">
                            <?php echo $icons['dashboard']; ?><span class="dock-label">Dashboard</span>
                        </a>
                        <a href="<?php echo e(route('admin.consultants.index')); ?>"
                            class="<?php echo e($dockActive('admin.consultants.*')); ?>">
                            <?php echo $icons['users']; ?><span class="dock-label">Consultores</span>
                        </a>
                        <a href="<?php echo e(route('settings')); ?>" class="<?php echo e($dockActive('settings*')); ?>">
                            <?php echo $icons['settings']; ?><span class="dock-label">Config</span>
                        </a>
                    <?php else: ?>
                        <a href="<?php echo e(route('dashboard')); ?>" class="<?php echo e($dockActive('dashboard')); ?>">
                            <?php echo $icons['dashboard']; ?><span class="dock-label">Dashboard</span>
                        </a>
                    <?php endif; ?>
                </div>
            </nav>
        </div>

        
        <div class="drawer-side z-40">
            <label for="app-drawer" aria-label="Fechar menu lateral" class="drawer-overlay"></label>

            <aside class="min-h-full border-r border-base-300 bg-base-200 transition-[width] duration-200 ease-in-out"
                :class="collapsed ? 'lg:w-24' : 'lg:w-72'">

                
                <div class="px-4 py-4 flex items-center justify-between">
                    <div class="flex items-center gap-2" :class="collapsed ? 'mx-auto' : ''">
                        <div class="hidden lg:block" x-show="!collapsed">
                            <div class="font-bold leading-tight">Painel</div>
                            <div class="text-xs opacity-70 capitalize"><?php echo e($role ?? 'user'); ?></div>
                        </div>
                    </div>
                    <button type="button" class="btn btn-ghost btn-sm hidden lg:flex" @click="toggle()"
                        :title="collapsed ? 'Expandir' : 'Recolher'">
                        <i class="fa-solid fa-angles-left transition" :class="collapsed ? '' : 'rotate-180'"></i>
                    </button>
                </div>

                
                <ul class="menu px-3 gap-2" x-show="!collapsed" x-transition>
                    <?php if($role === 'admin'): ?>
                        <li>
                            <a href="<?php echo e(route('admin.dashboard')); ?>"
                                class="<?php echo e(request()->routeIs('admin.dashboard') ? 'active' : ''); ?> flex items-center gap-3 py-3 rounded-lg hover:bg-base-100">
                                <?php echo $icons['dashboard']; ?><span>Dashboard</span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo e(route('admin.consultants.index')); ?>"
                                class="<?php echo e(request()->routeIs('admin.consultants.*') ? 'active' : ''); ?> flex items-center gap-3 py-3 rounded-lg hover:bg-base-100">
                                <?php echo $icons['users']; ?><span>Consultores</span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo e(route('settings')); ?>"
                                class="<?php echo e(request()->routeIs('settings*') ? 'active' : ''); ?> flex items-center gap-3 py-3 rounded-lg hover:bg-base-100">
                                <?php echo $icons['settings']; ?><span>Configurações</span>
                            </a>
                        </li>
                    <?php elseif($role === 'consultant'): ?>
                        <li>
                            <a href="<?php echo e($rConsultant('consultant.dashboard')); ?>"
                                class="<?php echo e(request()->routeIs('consultant.dashboard') ? 'active' : ''); ?> flex items-center gap-3 py-3 rounded-lg hover:bg-base-100">
                                <?php echo $icons['dashboard']; ?><span>Dashboard</span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo e($rConsultant('consultant.clients.index')); ?>"
                                class="<?php echo e(request()->routeIs('consultant.clients.*') ? 'active' : ''); ?> flex items-center gap-3 py-3 rounded-lg hover:bg-base-100">
                                <?php echo $icons['clients']; ?><span>Clientes</span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo e($rConsultant('consultant.tasks.index')); ?>"
                                class="<?php echo e(request()->routeIs('consultant.tasks.*') ? 'active' : ''); ?> flex items-center gap-3 py-3 rounded-lg hover:bg-base-100">
                                <?php echo $icons['tasks']; ?><span>Tarefas</span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo e($rConsultant('consultant.categories.index')); ?>"
                                class="<?php echo e(request()->routeIs('consultant.categories.*') ? 'active' : ''); ?> flex items-center gap-3 py-3 rounded-lg hover:bg-base-100">
                                <?php echo $icons['categories']; ?><span>Categorias</span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo e(route('settings')); ?>"
                                class="<?php echo e(request()->routeIs('settings*') ? 'active' : ''); ?> flex items-center gap-3 py-3 rounded-lg hover:bg-base-100">
                                <?php echo $icons['settings']; ?><span>Configurações</span>
                            </a>
                        </li>
                    <?php elseif($role === 'client'): ?>
                        <li>
                            <a href="<?php echo e($cHref('client.dashboard')); ?>"
                                class="<?php echo e(request()->routeIs('client.dashboard') ? 'active' : ''); ?> flex items-center gap-3 py-3 rounded-lg hover:bg-base-100">
                                <?php echo $icon('dashboard'); ?><span>Dashboard</span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo e($cHref('client.accounts.index')); ?>"
                                class="<?php echo e(request()->routeIs('client.accounts*') ? 'active' : ''); ?> flex items-center gap-3 py-3 rounded-lg hover:bg-base-100">
                                <?php echo $icon('accounts'); ?><span>Contas</span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo e($cHref('client.invoices.index')); ?>"
                                class="<?php echo e(request()->routeIs('client.invoices*') ? 'active' : ''); ?> flex items-center gap-3 py-3 rounded-lg hover:bg-base-100">
                                <?php echo $icon('invoices'); ?><span>Faturas</span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo e($cHref('client.goals.index')); ?>"
                                class="<?php echo e(request()->routeIs('client.goals') ? 'active' : ''); ?> flex items-center gap-3 py-3 rounded-lg hover:bg-base-100">
                                <?php echo $icon('monthly_goals'); ?><span>Metas mensais</span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo e($cHref('client.transactions.index')); ?>"
                                class="<?php echo e(request()->routeIs('client.transactions*') ? 'active' : ''); ?> flex items-center gap-3 py-3 rounded-lg hover:bg-base-100">
                                <?php echo $icon('transactions'); ?><span>Transações</span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo e($cHref('client.objectives.index')); ?>"
                                class="<?php echo e(request()->routeIs('client.objectives*') ? 'active' : ''); ?> flex items-center gap-3 py-3 rounded-lg hover:bg-base-100">
                                <?php echo $icon('objectives'); ?><span>Objetivos</span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo e($cHref('client.tasks.index')); ?>"
                                class="<?php echo e(request()->routeIs('client.tasks*') ? 'active' : ''); ?> flex items-center gap-3 py-3 rounded-lg hover:bg-base-100">
                                <?php echo $icon('tasks'); ?><span>Tarefas</span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo e($cHref('client.investments.index')); ?>"
                                class="<?php echo e(request()->routeIs('client.investments*') ? 'active' : ''); ?> flex items-center gap-3 py-3 rounded-lg hover:bg-base-100">
                                <?php echo $icon('investments'); ?><span>Investimentos</span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo e($cHref('client.accountability.index')); ?>"
                                class="<?php echo e(request()->routeIs('client.accountability*') ? 'active' : ''); ?> flex items-center gap-3 py-3 rounded-lg hover:bg-base-100">
                                <?php echo $icon('reports'); ?><span>Prestação de contas</span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo e(route('settings')); ?>"
                                class="<?php echo e(request()->routeIs('settings*') ? 'active' : ''); ?> flex items-center gap-3 py-3 rounded-lg hover:bg-base-100">
                                <?php echo $icon('settings'); ?><span>Configurações</span>
                            </a>
                        </li>
                    <?php else: ?>
                        <li>
                            <a href="<?php echo e(route('dashboard')); ?>"
                                class="<?php echo e(request()->routeIs('dashboard') ? 'active' : ''); ?> flex items-center gap-3 py-3 rounded-lg hover:bg-base-100">
                                <?php echo $icons['dashboard']; ?><span>Dashboard</span>
                            </a>
                        </li>
                    <?php endif; ?>
                </ul>

                
                <ul class="menu px-2 gap-4" x-show="collapsed" x-transition>
                    <?php if($role === 'admin'): ?>
                        <?php ($c = $collapsedLink('admin.dashboard')); ?>
                        <li class="flex justify-center tooltip tooltip-right" data-tip="Dashboard">
                            <a href="<?php echo e(route('admin.dashboard')); ?>" class="<?php echo e($c['a']); ?>"
                                aria-current="<?php echo e($c['aria']); ?>">
                                <span class="<?php echo e($c['icon']); ?>"><?php echo $icons['dashboard']; ?></span>
                                <span class="<?php echo e($c['label']); ?>">Dashboard</span>
                            </a>
                        </li>
                        <?php ($c = $collapsedLink('admin.consultants.*')); ?>
                        <li class="flex justify-center tooltip tooltip-right" data-tip="Consultores">
                            <a href="<?php echo e(route('admin.consultants.index')); ?>" class="<?php echo e($c['a']); ?>"
                                aria-current="<?php echo e($c['aria']); ?>">
                                <span class="<?php echo e($c['icon']); ?>"><?php echo $icons['users']; ?></span>
                                <span class="<?php echo e($c['label']); ?>">Consultores</span>
                            </a>
                        </li>
                        <?php ($c = $collapsedLink('settings*')); ?>
                        <li class="flex justify-center tooltip tooltip-right" data-tip="Configurações">
                            <a href="<?php echo e(route('settings')); ?>" class="<?php echo e($c['a']); ?>"
                                aria-current="<?php echo e($c['aria']); ?>">
                                <span class="<?php echo e($c['icon']); ?>"><?php echo $icons['settings']; ?></span>
                                <span class="<?php echo e($c['label']); ?>">Configurações</span>
                            </a>
                        </li>
                    <?php elseif($role === 'consultant'): ?>
                        <?php ($c = $collapsedLink('consultant.dashboard')); ?>
                        <li class="flex justify-center tooltip tooltip-right" data-tip="Dashboard">
                            <a href="<?php echo e($rConsultant('consultant.dashboard')); ?>" class="<?php echo e($c['a']); ?>"
                                aria-current="<?php echo e($c['aria']); ?>">
                                <span class="<?php echo e($c['icon']); ?>"><?php echo $icons['dashboard']; ?></span>
                                <span class="<?php echo e($c['label']); ?>">Dashboard</span>
                            </a>
                        </li>
                        <?php ($c = $collapsedLink('consultant.clients.*')); ?>
                        <li class="flex justify-center tooltip tooltip-right" data-tip="Clientes">
                            <a href="<?php echo e($rConsultant('consultant.clients.index')); ?>" class="<?php echo e($c['a']); ?>"
                                aria-current="<?php echo e($c['aria']); ?>">
                                <span class="<?php echo e($c['icon']); ?>"><?php echo $icons['clients']; ?></span>
                                <span class="<?php echo e($c['label']); ?>">Clientes</span>
                            </a>
                        </li>
                        <?php ($c = $collapsedLink('consultant.tasks.*')); ?>
                        <li class="flex justify-center tooltip tooltip-right" data-tip="Tarefas">
                            <a href="<?php echo e($rConsultant('consultant.tasks.index')); ?>" class="<?php echo e($c['a']); ?>"
                                aria-current="<?php echo e($c['aria']); ?>">
                                <span class="<?php echo e($c['icon']); ?>"><?php echo $icons['tasks']; ?></span>
                                <span class="<?php echo e($c['label']); ?>">Tarefas</span>
                            </a>
                        </li>
                        <?php ($c = $collapsedLink('consultant.categories.*')); ?>
                        <li class="flex justify-center tooltip tooltip-right" data-tip="Categorias">
                            <a href="<?php echo e($rConsultant('consultant.categories.index')); ?>"
                                class="<?php echo e($c['a']); ?>" aria-current="<?php echo e($c['aria']); ?>">
                                <span class="<?php echo e($c['icon']); ?>"><?php echo $icons['categories']; ?></span>
                                <span class="<?php echo e($c['label']); ?>">Categorias</span>
                            </a>
                        </li>
                        <?php ($c = $collapsedLink('settings*')); ?>
                        <li class="flex justify-center tooltip tooltip-right" data-tip="Configurações">
                            <a href="<?php echo e(route('settings')); ?>" class="<?php echo e($c['a']); ?>"
                                aria-current="<?php echo e($c['aria']); ?>">
                                <span class="<?php echo e($c['icon']); ?>"><?php echo $icons['settings']; ?></span>
                                <span class="<?php echo e($c['label']); ?>">Config</span>
                            </a>
                        </li>
                    <?php elseif($role === 'client'): ?>
                        <?php ($c = $collapsedLink('client.dashboard')); ?>
                        <li class="flex justify-center tooltip tooltip-right" data-tip="Dashboard">
                            <a href="<?php echo e($cHref('client.dashboard')); ?>" class="<?php echo e($c['a']); ?>"
                                aria-current="<?php echo e($c['aria']); ?>">
                                <span class="<?php echo e($c['icon']); ?>"><?php echo $icon('dashboard'); ?></span>
                                <span class="<?php echo e($c['label']); ?>">Dashboard</span>
                            </a>
                        </li>
                        <?php ($c = $collapsedLink('client.accounts*')); ?>
                        <li class="flex justify-center tooltip tooltip-right" data-tip="Contas">
                            <a href="<?php echo e($cHref('client.accounts.index')); ?>" class="<?php echo e($c['a']); ?>"
                                aria-current="<?php echo e($c['aria']); ?>">
                                <span class="<?php echo e($c['icon']); ?>"><?php echo $icon('accounts'); ?></span>
                                <span class="<?php echo e($c['label']); ?>">Contas</span>
                            </a>
                        </li>
                        <?php ($c = $collapsedLink('client.invoices*')); ?>
                        <li class="flex justify-center tooltip tooltip-right" data-tip="Faturas">
                            <a href="<?php echo e($cHref('client.invoices.index')); ?>" class="<?php echo e($c['a']); ?>"
                                aria-current="<?php echo e($c['aria']); ?>">
                                <span class="<?php echo e($c['icon']); ?>"><?php echo $icon('invoices'); ?></span>
                                <span class="<?php echo e($c['label']); ?>">Faturas</span>
                            </a>
                        </li>
                        <?php ($c = $collapsedLink('client.goals')); ?>
                        <li class="flex justify-center tooltip tooltip-right" data-tip="Metas">
                            <a href="<?php echo e($cHref('client.goals.index')); ?>" class="<?php echo e($c['a']); ?>"
                                aria-current="<?php echo e($c['aria']); ?>">
                                <span class="<?php echo e($c['icon']); ?>"><?php echo $icon('monthly_goals'); ?></span>
                                <span class="<?php echo e($c['label']); ?>">Metas</span>
                            </a>
                        </li>
                        <?php ($c = $collapsedLink('client.transactions*')); ?>
                        <li class="flex justify-center tooltip tooltip-right" data-tip="Transações">
                            <a href="<?php echo e($cHref('client.transactions.index')); ?>" class="<?php echo e($c['a']); ?>"
                                aria-current="<?php echo e($c['aria']); ?>">
                                <span class="<?php echo e($c['icon']); ?>"><?php echo $icon('transactions'); ?></span>
                                <span class="<?php echo e($c['label']); ?>">Transações</span>
                            </a>
                        </li>
                        <?php ($c = $collapsedLink('settings*')); ?>
                        <li class="flex justify-center tooltip tooltip-right" data-tip="Configurações">
                            <a href="<?php echo e(route('settings')); ?>" class="<?php echo e($c['a']); ?>"
                                aria-current="<?php echo e($c['aria']); ?>">
                                <span class="<?php echo e($c['icon']); ?>"><?php echo $icon('settings'); ?></span>
                                <span class="<?php echo e($c['label']); ?>">Config</span>
                            </a>
                        </li>
                    <?php else: ?>
                        <?php ($c = $collapsedLink('dashboard')); ?>
                        <li class="flex justify-center tooltip tooltip-right" data-tip="Dashboard">
                            <a href="<?php echo e(route('dashboard')); ?>" class="<?php echo e($c['a']); ?>"
                                aria-current="<?php echo e($c['aria']); ?>">
                                <span class="<?php echo e($c['icon']); ?>"><?php echo $icons['dashboard']; ?></span>
                                <span class="<?php echo e($c['label']); ?>">Dashboard</span>
                            </a>
                        </li>
                    <?php endif; ?>
                </ul>

            </aside>
        </div>
    </div>

</body>

</html>
<?php /**PATH C:\Users\user\Documents\GitHub\consultor-financeiro\resources\views\layouts\app.blade.php ENDPATH**/ ?>