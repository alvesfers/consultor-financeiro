<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'type' => 'info', // success | error | warning | info
    'icon' => null, // ex: "fa-solid fa-circle-check" (se null, define pelo type)
    'timeout' => 4000, // ms; 0 ou null para não esconder automaticamente
    'fixed' => true, // true = toast flutuante; false = inline
    'position' => 'top-right', // top-right | top-center | bottom-right | bottom-left
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'type' => 'info', // success | error | warning | info
    'icon' => null, // ex: "fa-solid fa-circle-check" (se null, define pelo type)
    'timeout' => 4000, // ms; 0 ou null para não esconder automaticamente
    'fixed' => true, // true = toast flutuante; false = inline
    'position' => 'top-right', // top-right | top-center | bottom-right | bottom-left
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php
    $typeClass =
        [
            'success' => 'alert-success',
            'error' => 'alert-error',
            'warning' => 'alert-warning',
            'info' => 'alert-info',
        ][$type] ?? 'alert-info';

    $iconClass =
        $icon ??
        match ($type) {
            'success' => 'fa-solid fa-circle-check',
            'error' => 'fa-solid fa-triangle-exclamation',
            'warning' => 'fa-solid fa-circle-exclamation',
            default => 'fa-solid fa-circle-info',
        };

    $posClass = match ($position) {
        'top-right' => 'fixed top-4 right-4',
        'top-center' => 'fixed top-4 left-1/2 -translate-x-1/2',
        'bottom-right' => 'fixed bottom-4 right-4',
        'bottom-left' => 'fixed bottom-4 left-4',
        default => '',
    };

    $wrapperClasses = $fixed ? "$posClass z-50 w-auto max-w-sm" : '';
?>

<div x-data="{ show: true }"
    <?php if($timeout): ?> x-init="setTimeout(() => show = false, <?php echo e((int) $timeout); ?>)" <?php endif; ?> x-show="show"
    x-transition:enter="transition ease-out duration-300" x-transition:enter-start="opacity-0 -translate-y-3"
    x-transition:enter-end="opacity-100 translate-y-0" x-transition:leave="transition ease-in duration-300"
    x-transition:leave-start="opacity-100 translate-y-0" x-transition:leave-end="opacity-0 -translate-y-3"
    class="<?php echo e($wrapperClasses); ?>">
    <div role="alert" class="alert <?php echo e($typeClass); ?> shadow-lg relative">
        <i class="<?php echo e($iconClass); ?> text-lg"></i>

        <div class="flex-1">
            <?php echo e($slot); ?>

        </div>

        <button @click="show = false" class="btn btn-sm btn-circle btn-ghost absolute right-2 top-2" aria-label="Fechar"
            type="button">✕</button>
    </div>
</div>
<?php /**PATH C:\Users\user\Documents\GitHub\consultor-financeiro\resources\views\components\alert.blade.php ENDPATH**/ ?>