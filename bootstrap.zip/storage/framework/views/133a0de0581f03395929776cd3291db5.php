

<?php $__env->startSection('content'); ?>
    <div class="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <div class="stats shadow col-span-1 lg:col-span-3">
            <div class="stat">
                <div class="stat-title">Consultores</div>
                <div class="stat-value"><?php echo e($totalConsultants); ?></div>
            </div>
            <div class="stat">
                <div class="stat-title">Clientes</div>
                <div class="stat-value"><?php echo e($totalClients); ?></div>
            </div>
        </div>

        <div class="card bg-base-200">
            <div class="card-body">
                <h2 class="card-title">Top consultores</h2>
                <ul class="space-y-2">
                    <?php $__empty_1 = true; $__currentLoopData = $topConsultants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <li class="flex items-center justify-between">
                            <span><?php echo e($c->user->name ?? '—'); ?></span>
                            <span class="badge badge-outline"><?php echo e($c->clients_count); ?> clientes</span>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <li>Nenhum consultor</li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>

        <div class="card bg-base-200 lg:col-span-2">
            <div class="card-body">
                <h2 class="card-title">Tarefas vencendo (7 dias)</h2>
                <ul class="divide-y divide-base-300">
                    <?php $__empty_1 = true; $__currentLoopData = $tasksExpiring; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <li class="py-2 flex items-center justify-between">
                            <div>
                                <div class="font-medium"><?php echo e($t->title); ?></div>
                                <div class="text-sm opacity-70">Cliente: <?php echo e($t->client->user->name ?? '—'); ?></div>
                            </div>
                            <div class="badge badge-warning">
                                <?php echo e(\Illuminate\Support\Carbon::parse($t->due_at)->format('d/m')); ?></div>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <li class="py-2">Sem tarefas próximas.</li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\user\Documents\GitHub\consultor-financeiro\resources\views\dashboards\admin.blade.php ENDPATH**/ ?>